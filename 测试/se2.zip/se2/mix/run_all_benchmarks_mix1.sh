#!/bin/bash
#
# run_all_benchmarks.sh
############## PATH VARIABLES: MODIFY ACCORDINGLY ################
# Install location of Gem5
GEM5_DIR=/home/yms/gem5
# Location of Gem5 configuration script
GEM5_CONFIG_PATH=$GEM5_DIR/configs/example/se2.py
# Location of NVMain configuration script
NVMAIN_CONFIG_PATH=/home/yms/nvmain/Config/myConfig/$1
# Install location of SPEC2006 benchmarks
SPEC_DIR=/home/yms/cpu2006
# Directory to place run output. Make sure this exists!
OUTPUT_DIR=/home/yms/ymsTest/$2
# Directory to the data of SPEC CPU 2006 benchmarks
SPEC_DATA_DIR=/home/yms/gem5/specData
##################################################################
ARGC=$# # Get number of arguments excluding arg0 (the script itself). Check for help message condition.
if [[ "$ARGC" != 2 ]]; then # Bad number of arguments.
    echo "run_all_benchmarks.sh"
    echo "This script runs a single gem5 simulation of a single SPEC CPU2006 benchmark for X86 ISA."
    echo ""
    echo "USAGE: run_all_benchmarks.sh"
    echo "EXAMPLE: ./run_all_benchmarks.sh"
    echo ""
    echo "A single --help help or -h argument will bring this message back."
    exit
fi

##################################################################
# SET BENCHMARKS
##################################################################
BENCHMARKS=(
mix1
)

##################################################################
# CONFIGURATION VARIABLES
##################################################################
NUM_CPUS=4
CPU_TYPE=detailed
#CPU_CLOCK=3GHz

#CACHELINE_SIZE=64

#L1I_SIZE=32kB
#L1I_ASSOC=8
#L1D_SIZE=32kB
#L1D_ASSOC=8
L1I_SIZE=16kB
L1I_ASSOC=2
L1D_SIZE=16kB
L1D_ASSOC=2

#L2_SIZE=256kB
#L2_ASSOC=8
L2_SIZE=4MB
L2_ASSOC=16

#L3_SIZE=$((2*NUM_CPUS))MB
#L3_ASSOC=16

MEM_SIZE=4GB

#FASTFORWARD_INSTS=20000000
#MAXINSTS=100000000

##################################################################
# RUN BENCHMARKS
##################################################################
for ((i = 0; i < 1; ++i))
do
    for benchmark in ${BENCHMARKS[@]}
    do
        # Run directory for the selected SPEC benchmark
        # RUN_DIR=$SPEC_DIR/benchspec/CPU2006/$benchmark/exe

        # Changing to SPEC benchmark runtime directory
        # cd $RUN_DIR/

        cd $SPEC_DATA_DIR/$benchmark/
        
        # File log for this script's stdout henceforth
        #SCRIPT_OUT=$OUTPUT_DIR/script_out/runscript-$benchmark-$i.log

        # LAUNCH GEM5 SIMULATION
        #$GEM5_DIR/build/X86/gem5.opt --outdir=$OUTPUT_DIR $GEM5_CONFIG_PATH --benchmark=$benchmark --benchmark_stdout=$OUTPUT_DIR/stdout/$benchmark-$i.out --benchmark_stderr=$OUTPUT_DIR/stderr/$benchmark-$i.err --fast-forward=$FASTFORWARD_INSTS --maxinsts=$MAXINSTS --num-cpus=$NUM_CPUS --cpu-type=$CPU_TYPE --cpu-clock=$CPU_CLOCK --caches --cacheline_size=$CACHELINE_SIZE --l1i_size=$L1I_SIZE --l1i_assoc=$L1I_ASSOC --l1d_size=$L1D_SIZE --l1d_assoc=$L1D_ASSOC --l2cache --l2_size=$L2_SIZE --l2_assoc=$L2_ASSOC --l3cache --l3_size=$L3_SIZE --l3_assoc=$L3_ASSOC --mem-type=NVMainMemory --mem-size=$MEM_SIZE --nvmain-warmup --nvmain-config=$NVMAIN_CONFIG_PATH | tee -a $SCRIPT_OUT
		$GEM5_DIR/build/X86/gem5.opt --redirect-stdout --outdir=$OUTPUT_DIR/$benchmark/ $GEM5_CONFIG_PATH --num-cpus=$NUM_CPUS --cpu-type=$CPU_TYPE --caches --l1d_size=$L1D_SIZE --l1i_size=$L1I_SIZE --l2cache --l2_size=$L2_SIZE --l1d_assoc=$L1D_ASSOC --l1i_assoc=$L1I_ASSOC --l2_assoc=$L2_ASSOC --mem-type=NVMainMemory --mem-size=$MEM_SIZE --nvmain-config=$NVMAIN_CONFIG_PATH -b $benchmark   -I 2000000000
		
        #mv $GEM5_DIR/m5out/stats.txt $GEM5_DIR/m5out/stats-$benchmark-$i.txt
    done
done
