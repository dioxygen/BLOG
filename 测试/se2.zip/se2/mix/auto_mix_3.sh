#!/bin/sh
#integer compute
./build/X86/gem5.opt --redirect-stdout --outdir=../wcn_test/config_reram_3/mix1 ./configs/example/se2_mix.py --num-cpus=4 --cpu-type=DerivO3CPU --caches --l1d_size=16kB --l1i_size=16kB --l2cache --l2_size=4MB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=16 --mem-type=NVMainMemory --mem-size=4GB --nvmain-config=../RRAM_wcn_3.config -b mix1 -I 500000000 &

./build/X86/gem5.opt --redirect-stdout --outdir=../wcn_test/config_reram_3/mix2 ./configs/example/se2_mix.py --num-cpus=4 --cpu-type=DerivO3CPU --caches --l1d_size=16kB --l1i_size=16kB --l2cache --l2_size=4MB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=16 --mem-type=NVMainMemory --mem-size=4GB --nvmain-config=../RRAM_wcn_3.config -b mix2 -I 500000000 &

./build/X86/gem5.opt --redirect-stdout --outdir=../wcn_test/config_reram_3/mix3 ./configs/example/se2_mix.py --num-cpus=4 --cpu-type=DerivO3CPU --caches --l1d_size=16kB --l1i_size=16kB --l2cache --l2_size=4MB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=16 --mem-type=NVMainMemory --mem-size=4GB --nvmain-config=../RRAM_wcn_3.config -b mix3 -I 500000000 &

./build/X86/gem5.opt --redirect-stdout --outdir=../wcn_test/config_reram_3/mix4 ./configs/example/se2_mix.py --num-cpus=4 --cpu-type=DerivO3CPU --caches --l1d_size=16kB --l1i_size=16kB --l2cache --l2_size=4MB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=16 --mem-type=NVMainMemory --mem-size=4GB --nvmain-config=../RRAM_wcn_3.config -b mix4 -I 500000000 &

./build/X86/gem5.opt --redirect-stdout --outdir=../wcn_test/config_reram_3/mix5 ./configs/example/se2_mix.py --num-cpus=4 --cpu-type=DerivO3CPU --caches --l1d_size=16kB --l1i_size=16kB --l2cache --l2_size=4MB --l1d_assoc=2 --l1i_assoc=2 --l2_assoc=16 --mem-type=NVMainMemory --mem-size=4GB --nvmain-config=../RRAM_wcn_3.config -b mix5 -I 500000000 &

