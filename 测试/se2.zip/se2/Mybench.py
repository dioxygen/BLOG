import m5
from m5.objects import *
m5.util.addToPath('../common')

binary_dir = '/home/bing/cpu2006/benchspec/CPU2006/'
data_dir = '/home/bing/cpu2006/benchspec/CPU2006/'

#====================
#400.perlbench
perlbench = Process(pid = 100)
perlbench.executable =  binary_dir+'400.perlbench/exe/perlbench_base.amd64-m64-gcc41-nn'
cmd1='-I'+data_dir+'400.perlbench/data/all/input/lib'
data=data_dir+'400.perlbench/data/all/input/diffmail.pl'
perlbench.cmd = [perlbench.executable] + [cmd1, data, '4', '800', '10', '17', '19', '300']
perlbench.output = data_dir+'400.perlbench/data/ref/output/diffmail.4.800.10.17.19.300.out'


#401.bzip2
bzip2 = Process(pid = 101)
bzip2.executable =  binary_dir+'401.bzip2/exe/bzip2_base.amd64-m64-gcc41-nn'
data=data_dir+'401.bzip2/data/all/input/input.combined'
bzip2.cmd = [bzip2.executable] + [data, '200']
bzip2.output = data_dir + '401.bzip2/data/ref/output/input.combined.out'


#====================
#403.gcc
gcc = Process(pid = 102)
gcc.executable =  binary_dir+'403.gcc/exe/gcc_base.amd64-m64-gcc41-nn'
data=data_dir+'403.gcc/data/ref/input/166.i'
zoutput = data_dir + '403.gcc/data/ref/output/166.s'
gcc.cmd = [gcc.executable] + [data, '-o', zoutput]
gcc.output =  data_dir + '403.gcc/data/ref/output/166.out'

#410.bwaves
bwaves = Process(pid = 103)
bwaves.executable =  binary_dir+'410.bwaves/exe/bwaves_base.amd64-m64-gcc41-nn'
bwaves.cmd = [bwaves.executable]


#====================
#416.gamess
gamess=Process(pid = 104)
gamess.executable =  binary_dir+'416.gamess/exe/gamess_base.amd64-m64-gcc41-nn'
gamess.cmd = [gamess.executable]
gamess.input=data_dir+'416.gamess/data/ref/input/cytosine.2.config'
gamess.output=data_dir+'416.gamess/data/ref/output/xxx.out'


#429.mcf
mcf = Process(pid = 105)
mcf.executable =  binary_dir+'429.mcf/exe/mcf_base.amd64-m64-gcc41-nn'
data=data_dir+'429.mcf/data/ref/input/inp.in'
mcf.cmd = [mcf.executable] + [data]
mcf.output = data_dir+'429.mcf/data/ref/output/inp.out'

#====================
#433.milc
milc=Process(pid = 106)
milc.executable = binary_dir+'433.milc/exe/milc_base.amd64-m64-gcc41-nn'
milc.input=data_dir+'433.milc/data/ref/input/su3imp.in'
milc.cmd = [milc.executable]
milc.output=data_dir+'433.milc/data/ref/output/su3imp.out'

#====================
#434.zeusmp
zeusmp=Process(pid = 107)
zeusmp.executable =  binary_dir+'434.zeusmp/exe/zeusmp_base.amd64-m64-gcc41-nn'
zeusmp.cmd = [zeusmp.executable]
zeusmp.output = data_dir+'434.zeusmp/data/ref/output/zeusmp.stdout'

#====================
#435.gromacs
gromacs = Process(pid = 108)
gromacs.executable =  binary_dir+'435.gromacs/exe/gromacs_base.amd64-m64-gcc41-nn'
data=data_dir+'435.gromacs/data/ref/input/gromacs'
gromacs.cmd = [gromacs.executable] + ['-silent','-deffnm',data,'-nice','0']

#====================
#436.cactusADM
cactusADM = Process(pid = 109)
cactusADM.executable =  binary_dir+'436.cactusADM/exe/cactusADM_base.amd64-m64-gcc41-nn'
data=data_dir+'436.cactusADM/data/ref/input/benchADM.par'
cactusADM.cmd = [cactusADM.executable] + [data]
cactusADM.output = data_dir+'436.cactusADM/data/ref/output/benchADM.out'

#437.leslie3d
leslie3d=Process(pid = 110)
leslie3d.executable =  binary_dir+'437.leslie3d/exe/leslie3d_base.amd64-m64-gcc41-nn'
leslie3d.cmd = [leslie3d.executable]
leslie3d.input=data_dir+'437.leslie3d/data/ref/input/leslie3d.in'
leslie3d.output=data_dir+'437.leslie3d/data/ref/output/leslie3d.stdout'

#444.namd
namd = Process(pid = 111)
namd.executable =  binary_dir+'444.namd/exe/namd_base.amd64-m64-gcc41-nn'
zinput=data_dir+'444.namd/data/all/input/namd.input'
zoutput=data_dir+'444.namd/data/ref/output/namd.out'
namd.cmd = [namd.executable] + ['--input',zinput,'--iterations','38','--output',zoutput]
namd.output=data_dir+'444.namd/data/ref/output/namd.stdout'

#445.gobmk
gobmk=Process(pid = 112)
gobmk.executable =  binary_dir+'445.gobmk/exe/gobmk_base.amd64-m64-gcc41-nn'
gobmk.cmd = [gobmk.executable]+['--quiet','--mode','gtp']
gobmk.input=data_dir+'445.gobmk/data/ref/input/trevord.tst'
gobmk.output=data_dir+'445.gobmk/data/ref/output/trevord.out'

#====================
#447.dealII
dealII=Process(pid = 113)
dealII.executable =  binary_dir+'447.dealII/exe/dealII_base.amd64-m64-gcc41-nn'
dealII.cmd = [dealII.executable]+['23']
dealII.output=data_dir + '447.dealII/data/ref/output/log'


#450.soplex
soplex=Process(pid = 114)
soplex.executable =  binary_dir+'450.soplex/exe/soplex_base.amd64-m64-gcc41-nn'
data=data_dir+'450.soplex/data/ref/input/ref.mps'
soplex.cmd = [soplex.executable]+['-m3500',data]
soplex.output = data_dir + '450.soplex/data/ref/output/ref.out'

#453.povray    no-running
povray=Process(pid = 115)
povray.executable =  binary_dir+'453.povray/exe/povray_base.amd64-m64-gcc41-nn'
data=data_dir+'453.povray/data/ref/input/SPEC-benchmark-ref.ini'
povray.cmd = [povray.executable]+[data]
povray.output = data_dir + '453.povray/data/ref/output/SPEC-benchmark-ref.stdout'

#454.calculix    computation-intensive
calculix=Process(pid = 116)
calculix.executable =  binary_dir+'454.calculix/exe/calculix_base.amd64-m64-gcc41-nn'
data=data_dir+'454.calculix/data/ref/input/hyperviscoplastic'
calculix.cmd = [calculix.executable]+['-i',data]
calculix.output =data_dir + '454.calculix/data/ref/output/hyperviscoplastic.log'

#456.hmmer
hmmer=Process(pid = 117)
hmmer.executable =  binary_dir+'456.hmmer/exe/hmmer_base.amd64-m64-gcc41-nn'
data=data_dir+'456.hmmer/data/ref/input/retro.hmm'
hmmer.cmd = [hmmer.executable]+['--fixed', '0', '--mean', '500', '--num', '500000', '--sd', '350', '--seed', '0', data]
hmmer.output = data_dir+'456.hmmer/data/ref/output/retro.out'

#458.sjeng
sjeng=Process(pid = 118)
sjeng.executable =  binary_dir+'458.sjeng/exe/sjeng_base.amd64-m64-gcc41-nn'
data=data_dir+'458.sjeng/data/ref/input/ref.txt'
sjeng.cmd = [sjeng.executable]+[data]
sjeng.output = data_dir+'458.sjeng/data/ref/output/ref.out'

#459.GemsFDTD     computation-intensive
GemsFDTD=Process(pid = 119)
GemsFDTD.executable =  binary_dir+'459.GemsFDTD/exe/GemsFDTD_base.amd64-m64-gcc41-nn'
GemsFDTD.cmd = [GemsFDTD.executable]
GemsFDTD.output = data_dir+'459.GemsFDTD/data/ref/output/ref.log'

#462.libquantum
libquantum=Process(pid = 120)
libquantum.executable =  binary_dir+'462.libquantum/exe/libquantum_base.amd64-m64-gcc41-nn'
libquantum.cmd = [libquantum.executable]+['1397','8']
libquantum.output = data_dir + '462.libquantum/data/ref/output/ref.out'

#464.h264ref
h264ref=Process(pid = 121)
h264ref.executable =  binary_dir+'464.h264ref/exe/h264ref_base.amd64-m64-gcc41-nn'
data=data_dir+'464.h264ref/data/ref/input/sss_encoder_main.cfg'
h264ref.cmd = [h264ref.executable]+['-d',data]
h264ref.output = data_dir+'464.h264ref/data/ref/output/foreman_ref_main_encodelog.out'

#470.lbm
lbm=Process(pid = 122)
lbm.executable =  binary_dir+'470.lbm/exe/lbm_base.amd64-m64-gcc41-nn'
data=data_dir+'470.lbm/data/ref/input/100_100_130_ldc.of'
lbm.cmd = [lbm.executable]+['3000', 'reference.dat', '0', '0' ,data]
lbm.output = data_dir+'470.lbm/data/ref/output/lbm.out'

#471.omnetpp
omnetpp=Process(pid = 123)
omnetpp.executable =  binary_dir+'471.omnetpp/exe/omnetpp_base.amd64-m64-gcc41-nn'
#data=data_dir+'471.omnetpp/data/ref/input/omnetpp.ini'
data='omnetpp.ini'
omnetpp.cmd = [omnetpp.executable]+[data]
omnetpp.output = data_dir+'471.omnetpp/data/ref/output/omnetpp.log'

#====================
#473.astar
astar=Process(pid = 124)
astar.executable =  binary_dir+'473.astar/exe/astar_base.amd64-m64-gcc41-nn'
#data = data_dir + '473.astar/data/ref/input/rivers.cfg'
data = 'rivers.cfg'
astar.cmd = [astar.executable]+[data]
astar.output = data_dir + '473.astar/data/ref/output/rivers.out'

#====================
#481.wrf
wrf=Process(pid = 125)
wrf.executable =  binary_dir+'481.wrf/exe/wrf_base.amd64-m64-gcc41-nn'
wrf.cmd = [wrf.executable]
wrf.output = data_dir + '481.wrf/data/ref/output/rsl.out.0000'

#482.sphinx
sphinx3=Process(pid = 126)
sphinx3.executable =  binary_dir+'482.sphinx3/exe/sphinx_livepretend_base.amd64-m64-gcc41-nn'
sphinx3.cmd = [sphinx3.executable]+['ctlfile', '.', 'args.an4']
sphinx3.output = data_dir + '482.sphinx3/data/ref/output/an4.out'

#483.xalancbmk   no-running
xalancbmk=Process(pid = 127)
xalancbmk.executable =  binary_dir+'483.xalancbmk/exe/Xalan_base.amd64-m64-gcc41-nn'
data1=data_dir + '483.xalancbmk/data/ref/input/t5.xml'
data2=data_dir + '483.xalancbmk/data/ref/input/xalanc.xsl'
#xalancbmk.cmd = [xalancbmk.executable]+['-v',data1, data2]
xalancbmk.cmd = [xalancbmk.executable]+['-v','t5.xml', 'xalanc.xsl']
xalancbmk.output = data_dir + '483.xalancbmk/data/ref/output/ref.out'

#998.specrand   memory-intensive
specrand_i=Process(pid = 128)
specrand_i.executable = binary_dir+'998.specrand/exe/specrand_base.amd64-m64-gcc41-nn'
specrand_i.cmd = [specrand_i.executable] + ['1255432124','234923']
specrand_i.output = data_dir + '998.specrand/data/ref/output/rand.234923.out'

#999.specrand   memory-intensive
specrand_f=Process(pid = 129)
specrand_f.executable = binary_dir+'999.specrand/exe/specrand_base.amd64-m64-gcc41-nn'
specrand_f.cmd = [specrand_i.executable] + ['1255432124','234923']
specrand_f.output =  data_dir + '999.specrand/data/ref/output/rand.234923.out'